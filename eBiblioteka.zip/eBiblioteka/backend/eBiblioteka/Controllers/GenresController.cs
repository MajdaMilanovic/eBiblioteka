﻿using eBiblioteka.Data;
using eBiblioteka.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace eBiblioteka.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class GenresController : ControllerBase
    {
        private readonly BibliotekaContext _context;

        public GenresController(BibliotekaContext context  )
        {
            _context = context;
        }

        [HttpGet()]
        public async Task<IEnumerable<Genres>> Get()
            => await _context.Genres.ToListAsync();

        [HttpGet("id")]
        public async Task<IActionResult> GetById(int id)
        {
            var genre = await _context.Genres.FindAsync(id);
            return genre == null ? NotFound() : Ok(genre);
        }

        [HttpPost()]
        public async Task<IActionResult> Create(Genres genre)
        {
            await _context.Genres.AddAsync(genre);
            await _context.SaveChangesAsync();
            return CreatedAtAction( nameof(GetById) , new { id=genre.GenreId}, genre);
        }


        [HttpPut()]
        public async Task<IActionResult> Update(int id, Genres genre)
        {
            if (id != genre.GenreId) return BadRequest();
            _context.Entry(genre).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            return NoContent();
        }


        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var genre = await _context.Genres.FindAsync(id);
            if (genre == null) return NotFound();

            _context.Genres.Remove(genre);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
