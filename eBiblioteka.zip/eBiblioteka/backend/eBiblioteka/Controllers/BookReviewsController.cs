﻿using eBiblioteka.Data;
using eBiblioteka.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace eBiblioteka.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class BookReviewsController : Controller
    {
        private readonly BibliotekaContext _context;
        public BookReviewsController(BibliotekaContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IEnumerable<BookReviews>> Get()
            => await _context.BookReviews.ToListAsync();

        [HttpGet("id")]
        public async Task<IActionResult> GetById(int id)
        {
            var bookReview = await _context.BookReviews.FindAsync(id);
            return bookReview == null ? NotFound() : Ok(bookReview);
        }
        [HttpPost]
        public async Task<IActionResult> Create(BookReviews bookReviews)
        {
            await _context.BookReviews.AddAsync(bookReviews);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetById), new { id = bookReviews.ReviewId }, bookReviews);
        }

        [HttpPut]
        public async Task<IActionResult> Update(int id, BookReviews review)
        {
            if (id != review.ReviewId) return BadRequest();
            _context.Entry(review).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            return NoContent();
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var review = await _context.BookReviews.FindAsync(id);
            if (review == null) return NotFound();

            _context.BookReviews.Remove(review);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
