﻿using eBiblioteka.Data;
using eBiblioteka.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace eBiblioteka.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class PublishersController : ControllerBase
    {
        private readonly BibliotekaContext _context;
        public PublishersController(BibliotekaContext context)
        {
            _context = context;
        }

        [HttpGet()]
        public async Task<IEnumerable<Publishers>> Get()
            => await _context.Publishers.ToListAsync();

        [HttpGet("id")]
        public async Task<IActionResult> GetById(int id)
        {
            var publisher = await _context.Publishers.FindAsync(id);
            return publisher == null ? NotFound() : Ok(publisher);
        }

        [HttpPost()]
        public async Task<IActionResult> Create(Publishers publisher)
        {
            await _context.Publishers.AddAsync(publisher);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetById), new { id = publisher.PublisherId }, publisher);
        }


        [HttpPut()]
        public async Task<IActionResult> Update (int id, Publishers publisher)
        {
            if (id != publisher.PublisherId) return BadRequest();
            _context.Entry(publisher).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var publisher = await _context.Publishers.FindAsync(id);
            if(publisher == null) return NotFound();

            _context.Publishers.Remove(publisher);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
