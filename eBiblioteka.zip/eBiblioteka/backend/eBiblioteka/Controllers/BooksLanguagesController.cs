﻿using eBiblioteka.Data;
using eBiblioteka.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace eBiblioteka.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class BooksLanguagesController : ControllerBase
    {

        private readonly BibliotekaContext _context;
        public BooksLanguagesController(BibliotekaContext context)
        {
            _context = context;
        }

        [HttpGet()]
       
        public async Task<IEnumerable<BooksLanguages>> Get()
        {
            return await _context.BooksLanguages.ToListAsync(); 

        }
        [HttpGet("id")]
        public async Task<IActionResult> GetById(int id)
        {
            var language = await _context.BooksLanguages.FindAsync(id);
            return language == null ? NotFound() : Ok(language);
        }

        [HttpPost()]
         public async Task<IActionResult> Create(BooksLanguages language)
        {
            await _context.BooksLanguages.AddAsync(language);
            await _context.SaveChangesAsync();
            return CreatedAtAction( nameof(GetById), new {id=language.LanguageId}, language);
        }
        [HttpPut()]
        public async Task<IActionResult> Update (int id, BooksLanguages language)
        {
            if (id != language.LanguageId) return BadRequest();
            _context.Entry(language).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return NoContent();
        }


        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var language = await _context.BooksLanguages.FindAsync(id);
            if (language == null) return NotFound();

            _context.BooksLanguages.Remove(language);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
