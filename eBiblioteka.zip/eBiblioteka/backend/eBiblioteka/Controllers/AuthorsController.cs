﻿using eBiblioteka.Data;
using eBiblioteka.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace eBiblioteka.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class AuthorsController : ControllerBase
    {
        private readonly BibliotekaContext _context;
        public AuthorsController(BibliotekaContext context)
        {
            _context = context;
        }

        //public async Task<ActionResult<IEnumerable<Authors>>> GetAuthors()
        //{
        //    if (_context.Authors == null)
        //        return NotFound();
        //    return await _context.Authors.ToListAsync();

        //}
        [HttpGet()]
         public async Task<IEnumerable<Authors>> Get()
         {
            return await _context.Authors.ToListAsync();
         }

        [HttpGet("id")]
        public async Task<IActionResult> GetById(int id)
        {
            var author = await _context.Authors.FindAsync(id);
            return author == null ? NotFound() : Ok(author);
        }

        [HttpPost()]
        public async Task<IActionResult> Create(Authors author)
        {
            await _context.Authors.AddAsync(author);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetById), new { id=author.AuthorId}, author);
        }


        [HttpPut()]
        public async Task<IActionResult> Update(int id, Authors author)
        {
            if (id != author.AuthorId) return BadRequest();
            _context.Entry(author).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            return NoContent();
        }


        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var author = await _context.Authors.FindAsync(id);
            if (author == null) return NotFound();

            _context.Authors.Remove(author);
            await _context.SaveChangesAsync();

            return NoContent();
        }

    }
}
