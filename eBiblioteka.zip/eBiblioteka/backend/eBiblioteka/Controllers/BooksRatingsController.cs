﻿using eBiblioteka.Data;
using eBiblioteka.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace eBiblioteka.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class BooksRatingsController : ControllerBase
    {
        private readonly BibliotekaContext _context;

        public BooksRatingsController(BibliotekaContext context)
        {
            _context = context;
        }


        [HttpGet()]
        public async Task<IEnumerable<BooksRatings>> Get()
            => await _context.BooksRatings.ToListAsync();

        [HttpGet("id")]
        public async Task<IActionResult> GetById(int id)
        {
            var rating = await _context.BooksRatings.FindAsync(id);
            return rating == null ? NotFound() : Ok(rating);
        }

        [HttpPost()]
        public async Task<IActionResult> Create (BooksRatings rating)
        {
            await _context.BooksRatings.AddAsync(rating);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetById), new { id = rating.RatingId }, rating);
        }
        [HttpPut()]
        public async Task<IActionResult> Update(int id, BooksRatings rating)
        {
            if (id != rating.RatingId) return BadRequest();
            _context.Entry(rating).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            return NoContent();
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var rating = await _context.BooksRatings.FindAsync(id);
            if (rating == null) return NotFound();

            _context.BooksRatings.Remove(rating);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
