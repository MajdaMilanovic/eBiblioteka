﻿using eBiblioteka.Data;
using eBiblioteka.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace eBiblioteka.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class TransactionsController : ControllerBase
    {
        private readonly BibliotekaContext _context;

        public TransactionsController(BibliotekaContext context)
        {
            _context = context;
        }

        [HttpGet()]
        public async Task<IEnumerable<Transactions>> Get()
            => await _context.Transactions.ToListAsync();

        [HttpGet("id")]
        public async Task<IActionResult> GetById(int id)
        {
            var transaction = await _context.Transactions.FindAsync(id);
            return transaction == null ? NotFound() : Ok(transaction);
        }

        [HttpPost()]
        public async Task<IActionResult> Create(Transactions transaction)
        {
            await _context.Transactions.AddAsync(transaction);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetById), new {id=transaction.TransactionId}, transaction);
        }

        [HttpPut()]
        public async Task<IActionResult> Update (int id, Transactions transaction)
        {
            if (id != transaction.TransactionId) return BadRequest();
            _context.Entry(transaction).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete (int id)
        {
            var transaction = await _context.Transactions.FindAsync(id);
            if (transaction == null) return NotFound();

            _context.Transactions.Remove(transaction);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
