﻿using eBiblioteka.Data;
using eBiblioteka.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace eBiblioteka.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class BookReservationsController : ControllerBase
    {

        private readonly BibliotekaContext _context;
        public BookReservationsController(BibliotekaContext context)
        {
            _context = context;
        }

        [HttpGet()]
        public async Task<IEnumerable<BookReservations>> Get()
            => await _context.BookReservations.ToListAsync();

        [HttpGet("id")]
        public async Task<IActionResult> GetById(int id)
        {
            var bookReservation = await _context.BookReservations.FindAsync(id);
            return bookReservation == null ? NotFound() : Ok(bookReservation);
        }

        [HttpPost()]
        public async Task<IActionResult> Create(BookReservations reservation)
        {
            await _context.BookReservations.AddAsync(reservation);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetById), new { id = reservation.ReservationId }, reservation);
        }
        

        [HttpPut()]
        public async Task<IActionResult> Update(int id, BookReservations reservation)
        {
            if (id != reservation.ReservationId) return BadRequest();
            _context.Entry(reservation).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return NoContent();
        }


        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var reservation = await _context.BookReservations.FindAsync(id);
            if (reservation == null) return NotFound();

            _context.BookReservations.Remove(reservation);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
