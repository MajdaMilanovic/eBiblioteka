﻿using eBiblioteka.Data;
using eBiblioteka.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace eBiblioteka.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class UserRolesController : ControllerBase
    {
        private readonly BibliotekaContext _context;
        public UserRolesController(BibliotekaContext context)
        {
            _context = context;
        }

        [HttpGet()]
        public async Task<IEnumerable<UserRoles>> Get()
            => await _context.UserRoles.ToListAsync();


        [HttpGet("id")]
        public async Task<IActionResult> GetById (int id)
        {
            var role = await _context.UserRoles.FindAsync(id);
            return role == null ? NotFound() : Ok(role);
        }

        [HttpPost()]
        public async Task<IActionResult> Create(UserRoles role)
        {
            await _context.UserRoles.AddAsync(role);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetById), new { id = role.RoleId }, role);
        }

        [HttpPut()]
        public async Task<IActionResult> Update(int id, UserRoles role)
        {
            if (id != role.RoleId) return BadRequest();
            _context.Entry(role).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            return NoContent();
        }


        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete (int id)
        {
            var role = await _context.UserRoles.FindAsync(id);
            if (role == null) return NotFound();

            _context.UserRoles.Remove(role);
            await _context.SaveChangesAsync();

            return NoContent();
        }

    }
}
