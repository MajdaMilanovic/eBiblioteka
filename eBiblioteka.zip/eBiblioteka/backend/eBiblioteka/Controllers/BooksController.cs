﻿using eBiblioteka.Data;
using eBiblioteka.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace eBiblioteka.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class BooksController : ControllerBase
    {

        private readonly BibliotekaContext _context;
        public BooksController(BibliotekaContext context)
        {
            _context = context;
        }

        [HttpGet()]
        public async Task<IEnumerable<Books>> Get()
        {
            return await _context.Books.ToListAsync();
        }

        [HttpGet("id")]
        public async Task<IActionResult> GetById(int id)
        {
            var book = await _context.Books.FindAsync(id);
            return book == null ? NotFound() : Ok(book);
        }

        [HttpPost()]
         public async Task<IActionResult> Create (Books book)
        {
            await _context.Books.AddAsync(book);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetById), new { id = book.BookId }, book);
        }

        [HttpPut()]
        public async Task <IActionResult> Update (int id, Books book)
        {
            if (id != book.BookId) return BadRequest();

            _context.Entry(book).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            return NoContent();
        }


        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete (int id)
        {
            var book = await _context.Books.FindAsync (id);
            if (book == null) return NotFound();

            _context.Books.Remove(book);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
