﻿using System.ComponentModel.DataAnnotations;

namespace eBiblioteka.Models
{
    public class UserRoles
    {
        [Key]
        public int RoleId { get; set; }
        public string RoleName { get; set; }
    }
}
