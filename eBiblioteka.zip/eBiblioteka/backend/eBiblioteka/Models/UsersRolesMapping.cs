﻿using System.ComponentModel.DataAnnotations.Schema;

namespace eBiblioteka.Models
{
    public class UsersRolesMapping
    {
        public int UserId { get; set; }
        public int UserRoleId { get; set; }

        [ForeignKey("UserId")]
        public virtual Users User { get; set; }

        [ForeignKey("UserRoleId")]
        public virtual UserRoles UserRole { get; set; }
    }
}
