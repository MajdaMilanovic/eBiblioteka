﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace eBiblioteka.Models
{
    public class BookReviews
    {
        [Key]
        public int ReviewId { get; set; }
        [ForeignKey(nameof(User))]
        public int UserId { get; set; }
        public Users User { get; set; }
        [ForeignKey(nameof(Book))]
        public int BookId { get; set; }
        public Books Book { get; set; }
        public string  ReviewText { get; set; }
        public DateTime ReviewDate { get; set; }
    }
}
