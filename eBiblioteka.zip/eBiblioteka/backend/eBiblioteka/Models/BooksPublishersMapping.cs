﻿using System.ComponentModel.DataAnnotations.Schema;

namespace eBiblioteka.Models
{
    public class BooksPublishersMapping
    {
        public int BookId { get; set; }
        public int PublisherId { get; set; }

        [ForeignKey("BookId")]
        public virtual Books Book { get; set; }
        [ForeignKey("PublisherId")]
        public virtual Publishers Publisher { get; set; }
    }
}
