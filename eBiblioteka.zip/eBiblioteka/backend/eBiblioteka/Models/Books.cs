﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace eBiblioteka.Models
{
    public class Books
    {
        [Key]
        public int BookId { get; set; }
        public string Title { get; set; }
        [ForeignKey(nameof(Author))]
        public int AuthorId { get; set; }
        public Authors Author { get; set; }
        public string Genre { get; set; }
        public int MyProperty { get; set; }
        public DateTime PublicationDate { get; set; }
    }
}
