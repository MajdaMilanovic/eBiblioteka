﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace eBiblioteka.Models
{
    public class Transactions
    {
        [Key]
        public int TransactionId { get; set; }
        [ForeignKey(nameof(User))]
        public int UserId { get; set; }
        public Users User { get; set; }
        [ForeignKey(nameof(Book))]
        public int BookId { get; set; }
        public Books Book { get; set; }
        public DateTime CheckoutTime { get; set; }
        public DateTime ReturnDate { get; set; }
        public string Status { get; set; }
    }
}
