﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace eBiblioteka.Models
{
    public class AuthorsBooksMapping
    {
        
        public int AuthorId { get; set; }
       
        public int BookId { get; set; }

        [ForeignKey("AuthorId")]
        public virtual Authors Author { get; set; }
        [ForeignKey("BookId")]
        public virtual Books Book { get; set; }
    }
}
