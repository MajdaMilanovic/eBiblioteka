﻿using System.ComponentModel.DataAnnotations.Schema;

namespace eBiblioteka.Models
{
    public class BooksGenresMapping
    {
        public int BookId { get; set; }
        public int GenreId { get; set; }

        [ForeignKey("BookId")]
        public virtual Books Book { get; set; }
        [ForeignKey("GenreId")]
        public virtual Genres Genre { get; set; }
    }
}
