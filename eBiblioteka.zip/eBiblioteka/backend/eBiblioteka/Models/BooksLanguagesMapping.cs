﻿using System.ComponentModel.DataAnnotations.Schema;

namespace eBiblioteka.Models
{
    public class BooksLanguagesMapping
    {
        public int BookId { get; set; }
        public int LanguageId { get; set; }

        [ForeignKey("BookId")]
        public virtual Books Book { get; set; }
        [ForeignKey("LanguageId")]
        public virtual BooksLanguages Language { get; set; }
    }
}
