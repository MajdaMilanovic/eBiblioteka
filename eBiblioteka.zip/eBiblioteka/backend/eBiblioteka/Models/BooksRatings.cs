﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace eBiblioteka.Models
{
    public class BooksRatings
    {
        [Key]
        public int RatingId { get; set; }
        [ForeignKey(nameof(User))]
        public int UserId { get; set; }
        [ForeignKey(nameof(Book))]
        public int BookId { get; set; }

        public Users User { get; set; }
        public Books Book { get; set; }
        public DateTime RatingDate { get; set; }
        public int Rating { get; set; }
    }
}
