﻿using System.ComponentModel.DataAnnotations;

namespace eBiblioteka.Models
{
    public class Authors
    {
        [Key]
        public int AuthorId { get; set; }
        public string Name { get; set; }
        public string Biography { get; set; }
        public DateTime BirthDate { get; set; }
    }
}