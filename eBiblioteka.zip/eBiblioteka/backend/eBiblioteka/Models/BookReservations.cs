﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace eBiblioteka.Models
{
    public class BookReservations
    {
        [Key]
        public int ReservationId { get; set; }
        [ForeignKey(nameof(User))]
        public int UserId { get; set; }
        public Users User { get; set; }
        [ForeignKey(nameof(Book))]
        public int BookId { get; set; }
        public Books Book { get; set; }
        public DateTime ReservationDate { get; set; }
        public string Status { get; set; }
    }
}
