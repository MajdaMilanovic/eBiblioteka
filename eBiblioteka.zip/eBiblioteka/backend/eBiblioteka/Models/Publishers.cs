﻿using System.ComponentModel.DataAnnotations;

namespace eBiblioteka.Models
{
    public class Publishers
    {
        [Key]
        public int PublisherId { get; set; }
        public string PublisherName { get; set; }
        public string ContactInformation { get; set; }
    }
}
