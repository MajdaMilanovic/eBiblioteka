﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace eBiblioteka.Migrations
{
    public partial class updskripta2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "AuthorsBooksMapping",
                columns: table => new
                {
                    AuthorId = table.Column<int>(type: "int", nullable: false),
                    BookId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AuthorsBooksMapping", x => new { x.AuthorId, x.BookId });
                    table.ForeignKey(
                        name: "FK_AuthorsBooksMapping_Authors_AuthorId",
                        column: x => x.AuthorId,
                        principalTable: "Authors",
                        principalColumn: "AuthorId",
                        onDelete: ReferentialAction.NoAction);
                    table.ForeignKey(
                        name: "FK_AuthorsBooksMapping_Books_BookId",
                        column: x => x.BookId,
                        principalTable: "Books",
                        principalColumn: "BookId",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateTable(
                name: "BooksGenresMapping",
                columns: table => new
                {
                    BookId = table.Column<int>(type: "int", nullable: false),
                    GenreId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BooksGenresMapping", x => new { x.GenreId, x.BookId });
                    table.ForeignKey(
                        name: "FK_BooksGenresMapping_Books_BookId",
                        column: x => x.BookId,
                        principalTable: "Books",
                        principalColumn: "BookId",
                        onDelete: ReferentialAction.NoAction);
                    table.ForeignKey(
                        name: "FK_BooksGenresMapping_Genres_GenreId",
                        column: x => x.GenreId,
                        principalTable: "Genres",
                        principalColumn: "GenreId",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateTable(
                name: "BooksLanguagesMapping",
                columns: table => new
                {
                    BookId = table.Column<int>(type: "int", nullable: false),
                    LanguageId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BooksLanguagesMapping", x => new { x.BookId, x.LanguageId });
                    table.ForeignKey(
                        name: "FK_BooksLanguagesMapping_Books_BookId",
                        column: x => x.BookId,
                        principalTable: "Books",
                        principalColumn: "BookId",
                        onDelete: ReferentialAction.NoAction);
                    table.ForeignKey(
                        name: "FK_BooksLanguagesMapping_BooksLanguages_LanguageId",
                        column: x => x.LanguageId,
                        principalTable: "BooksLanguages",
                        principalColumn: "LanguageId",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateTable(
                name: "BooksPublishersMapping",
                columns: table => new
                {
                    BookId = table.Column<int>(type: "int", nullable: false),
                    PublisherId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BooksPublishersMapping", x => new { x.BookId, x.PublisherId });
                    table.ForeignKey(
                        name: "FK_BooksPublishersMapping_Books_BookId",
                        column: x => x.BookId,
                        principalTable: "Books",
                        principalColumn: "BookId",
                        onDelete: ReferentialAction.NoAction);
                    table.ForeignKey(
                        name: "FK_BooksPublishersMapping_Publishers_PublisherId",
                        column: x => x.PublisherId,
                        principalTable: "Publishers",
                        principalColumn: "PublisherId",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateTable(
                name: "UsersRolesMapping",
                columns: table => new
                {
                    UserId = table.Column<int>(type: "int", nullable: false),
                    UserRoleId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UsersRolesMapping", x => new { x.UserId, x.UserRoleId });
                    table.ForeignKey(
                        name: "FK_UsersRolesMapping_UserRoles_UserRoleId",
                        column: x => x.UserRoleId,
                        principalTable: "UserRoles",
                        principalColumn: "RoleId",
                        onDelete: ReferentialAction.NoAction);
                    table.ForeignKey(
                        name: "FK_UsersRolesMapping_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateIndex(
                name: "IX_AuthorsBooksMapping_BookId",
                table: "AuthorsBooksMapping",
                column: "BookId");

            migrationBuilder.CreateIndex(
                name: "IX_BooksGenresMapping_BookId",
                table: "BooksGenresMapping",
                column: "BookId");

            migrationBuilder.CreateIndex(
                name: "IX_BooksLanguagesMapping_LanguageId",
                table: "BooksLanguagesMapping",
                column: "LanguageId");

            migrationBuilder.CreateIndex(
                name: "IX_BooksPublishersMapping_PublisherId",
                table: "BooksPublishersMapping",
                column: "PublisherId");

            migrationBuilder.CreateIndex(
                name: "IX_UsersRolesMapping_UserRoleId",
                table: "UsersRolesMapping",
                column: "UserRoleId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AuthorsBooksMapping");

            migrationBuilder.DropTable(
                name: "BooksGenresMapping");

            migrationBuilder.DropTable(
                name: "BooksLanguagesMapping");

            migrationBuilder.DropTable(
                name: "BooksPublishersMapping");

            migrationBuilder.DropTable(
                name: "UsersRolesMapping");
        }
    }
}
