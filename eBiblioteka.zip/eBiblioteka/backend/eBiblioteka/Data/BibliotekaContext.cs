﻿using eBiblioteka.Models;
using Microsoft.EntityFrameworkCore;

namespace eBiblioteka.Data
{
    public class BibliotekaContext : ApplicationDbContext
    {
        public BibliotekaContext(DbContextOptions options) : base(options)
        {
        }

             public DbSet<Authors> Authors { get; set; }
             public DbSet<Books> Books { get; set; }
             public DbSet<Users> Users { get; set; }
             public DbSet<Publishers> Publishers { get; set; }
             public DbSet<Genres> Genres { get; set; }
             public DbSet<BookReservations> BookReservations { get; set; }
             public DbSet<Transactions> Transactions { get; set; }
             public DbSet<UserRoles> UserRoles { get; set; }
             public DbSet<BookReviews> BookReviews { get; set; }
             public DbSet<BooksRatings> BooksRatings { get; set; }
             public DbSet<BooksLanguages> BooksLanguages { get; set; }
        public DbSet<AuthorsBooksMapping> AuthorsBooksMapping { get; set; }
        public DbSet<BooksLanguagesMapping> BooksLanguagesMapping { get; set; }
        public DbSet<UsersRolesMapping> UsersRolesMapping { get; set; }
        public DbSet<BooksGenresMapping> BooksGenresMapping { get; set; }
        public DbSet<BooksPublishersMapping> BooksPublishersMapping { get; set; }



        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        => optionsBuilder.UseSqlServer("Data Source=localhost;Initial Catalog=eBiblioteka; Trusted_connection=True; TrustServerCertificate=True;");

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //base.OnModelCreating(modelBuilder); 

            modelBuilder.Entity<AuthorsBooksMapping>().HasKey(x => new { x.AuthorId, x.BookId });
            modelBuilder.Entity<BooksGenresMapping>().HasKey(x => new { x.GenreId, x.BookId });
            modelBuilder.Entity<BooksLanguagesMapping>().HasKey(x => new { x.BookId, x.LanguageId});
            modelBuilder.Entity<BooksPublishersMapping>().HasKey(x => new { x.BookId, x.PublisherId });
            modelBuilder.Entity<UsersRolesMapping>().HasKey(x => new { x.UserId, x.UserRoleId});

        }
    }
}
